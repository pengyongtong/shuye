#ifndef _B_USART_H_
#define _B_USART_H_

#include "stm32f10x.h"



void USART3_Init(u32 bound);



#endif
