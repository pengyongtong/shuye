#ifndef __B_TIMER_H__
#define __B_TIMER_H__

#include "global.h"


void TIM3_Init(u16 arr,u16 psc);
 
#endif
