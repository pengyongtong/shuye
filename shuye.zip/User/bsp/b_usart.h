#ifndef __B_USART_H__
#define __B_USART_H__

#include "sys.h"




void USART1_init(u32 bound);



#endif
