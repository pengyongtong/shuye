#include "b_down.h"


//PC1,PC13,      PA0
void Down_init()
{
	GPIO_InitTypeDef GPIO_InitTypeDefs;
	EXTI_InitTypeDef EXTI_InitStructs;
	NVIC_InitTypeDef NVIC_InitStructure;	

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOC,ENABLE);
	
	GPIO_InitTypeDefs.GPIO_Mode =GPIO_Mode_IPU;
	GPIO_InitTypeDefs.GPIO_Pin =GPIO_Pin_1|GPIO_Pin_13;
	GPIO_Init(GPIOC, &GPIO_InitTypeDefs); 
	
	GPIO_InitTypeDefs.GPIO_Mode =GPIO_Mode_IPD;
	GPIO_InitTypeDefs.GPIO_Pin =GPIO_Pin_0;
	GPIO_Init(GPIOA, &GPIO_InitTypeDefs); 
	
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource1);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource13);	
	
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2 ;//��ռ���ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		//�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);	//����ָ���Ĳ�����ʼ��VIC�Ĵ���
	EXTI_InitStructs.EXTI_Line =EXTI_Line1;
	EXTI_InitStructs.EXTI_LineCmd =ENABLE;
	EXTI_InitStructs.EXTI_Mode =EXTI_Mode_Interrupt;
	EXTI_InitStructs.EXTI_Trigger =EXTI_Trigger_Falling;
	
	EXTI_Init(&EXTI_InitStructs);
	

	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2 ;//��ռ���ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		//�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);	//����ָ���Ĳ�����ʼ��VIC�Ĵ���
	EXTI_InitStructs.EXTI_Line =EXTI_Line13;
	EXTI_InitStructs.EXTI_LineCmd =ENABLE;
	EXTI_InitStructs.EXTI_Mode =EXTI_Mode_Interrupt;
	EXTI_InitStructs.EXTI_Trigger =EXTI_Trigger_Falling;
	
	EXTI_Init(&EXTI_InitStructs);	
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2 ;//��ռ���ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		//�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);	//����ָ���Ĳ�����ʼ��VIC�Ĵ���		
	EXTI_InitStructs.EXTI_Line =EXTI_Line0;
	EXTI_InitStructs.EXTI_LineCmd =ENABLE;
	EXTI_InitStructs.EXTI_Mode =EXTI_Mode_Interrupt;
	EXTI_InitStructs.EXTI_Trigger =EXTI_Trigger_Rising;
	
	EXTI_Init(&EXTI_InitStructs);
}



u8 An_f=0;
void EXTI1_IRQHandler()
{

	uint16_t a;
	if(EXTI_GetITStatus(EXTI_Line1)==SET)
	{
	for(a=0;a<65530;a++);
	for(a=0;a<65530;a++);
	for(a=0;a<65530;a++);	
	for(a=0;a<65530;a++);			
	if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_1) !=SET)An_f|=0x80;
	while(!(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_1)==SET));				
	EXTI_ClearITPendingBit(EXTI_Line1);
	}
		
	
	
}

