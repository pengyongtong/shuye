#include "mb_uart1.h"
#include "b_usart.h"
#include "stdio.h"
#include "stdint.h"

int fputc(int ch, FILE *f) //�ض���printf
{
   USART_SendData(USART1, (unsigned char) ch);// USART1 ���Ի��� USART2 ��
   while (!(USART1->SR & USART_FLAG_TXE));
   return (ch);
}

int GetKey (void)   //�ض���getchar
{
   while (!(USART1->SR & USART_FLAG_RXNE));
   return ((int)(USART1->DR & 0x1FF));
}




void UART1_init(void)
{
	USART1_init(115200);






}




void USART1_IRQHandler(void)                	//����1�жϷ������
{
	u8 Res;
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) 
 {
		Res =USART_ReceiveData(USART1);	//��ȡ���յ�������
	 USART_SendData(USART3, Res);
	 while(!USART_GetFlagStatus(USART3, USART_FLAG_TXE));
//	 USART_SendData(USART1, Res);
//	 while(!USART_GetFlagStatus(USART1, USART_FLAG_TXE));	 
	 
	 
 } 
	USART_ClearITPendingBit(USART1, USART_IT_RXNE);
} 









