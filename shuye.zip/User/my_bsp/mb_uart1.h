#ifndef __MB_UART1_H__
#define __MB_UART1_H__

#include "delay.h"




void UART1_init(void);














#endif
