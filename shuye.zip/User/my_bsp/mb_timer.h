#ifndef __MB_TIMER_H
#define __MB_TIMER_H
#include "global.h"



void TIM3_Int_Init(void);
 
#endif
