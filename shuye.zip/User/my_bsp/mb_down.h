#ifndef __MB_DOWN_H__
#define __MB_DOWN_H__

#include "delay.h"



void key_init(void);











#endif

