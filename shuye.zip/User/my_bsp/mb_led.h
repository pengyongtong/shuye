#ifndef __MB_LED_H__
#define __MB_LED_H__







#define LED0 PBout(7)// PB5
#define LED1 PEout(12)// PE5	





void LED_init(void);







#endif
