#ifndef __MB_PUMP_H__
#define __MB_PUMP_H__






#include "delay.h"






#define PUMP_SET PBout(14)// PB5
#define PUMP_ON  {PBout(14)=SET;}
#define PUMP_OFF {PBout(14)=RESET;}

void pump_Init(void);
void pump_open(u16 time);









#endif

