#include "mb_pump.h"
#include "b_pump.h"
#include "mytype.h"


void pump_Init()
{
	pump_gpioInit();

}




void pump_open(u16 time)
{
	delay_ms(time);
	PUMP_ON;
	delay_ms(time);
	PUMP_OFF;
}
