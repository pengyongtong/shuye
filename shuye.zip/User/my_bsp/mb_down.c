#include "mb_down.h"
#include "b_down.h"



void key_init(void)
{

	Down_init();


}


void EXTI15_10_IRQHandler()
{
	uint16_t a;
	if(EXTI_GetITStatus(EXTI_Line13)==SET)
	{
	for(a=0;a<65530;a++);	
	for(a=0;a<65530;a++);		
	for(a=0;a<65530;a++);	
	for(a=0;a<65530;a++);			
	if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_13) !=SET)An_f|=0x40;
	while(!(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_13)==SET));			
	}
	EXTI_ClearITPendingBit(EXTI_Line13);	
}

void EXTI0_IRQHandler()
{
	uint16_t a;
	if(EXTI_GetITStatus(EXTI_Line0)==SET)
	{
	for(a=0;a<65530;a++);	
	for(a=0;a<65530;a++);
	for(a=0;a<65530;a++);	
	for(a=0;a<65530;a++);			
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) ==SET)An_f|=0x20;
	while(!(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)==RESET));	
	}
	EXTI_ClearITPendingBit(EXTI_Line0);
}

//����ʾ��

//		if(An_f & 0x80)
//		{
//			An_f &= 0x7f;
//			printf("11111��\r\n");
//			
//		}
//		if(An_f & 0x40)
//		{
//			An_f &=0xBf;
//			printf("2222��\r\n");
//			
//		}
//		if(An_f & 0x20)
//		{
//			An_f &=0xDf;
//			printf("3333��\r\n");
//			
//		}
