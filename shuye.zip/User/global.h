#ifndef _GLOBAL_H_
#define _GLOBAL_H_



#include "delay.h"
#include "mycfg.h"
#include "global.h"
#include "sys.h"
#include "mytype.h"
#include "delay.h"
#include "stdio.h"
#include "mb_blood.h"
#include "string.h"




#define U3RXLEN      50
#define PARSE_BLOOD_CYCLE    60  //����Ѫѹ��������<=24��
#define BLOOD_LEN   51 //Ѫѹ��Ч��Ϣ����



extern u8 blood_data[BLOOD_LEN];
extern u8 uart3Rxbuf[U3RXLEN];
extern u8 u3cnt;
extern u8 rcv_hander1;
extern u8 rcv_hander2;
extern u8 rcv_hander3;
extern u8 rcv_hander4;
extern u8 rcv_hander5;
extern u8 rcv_hander6;
extern u8 rcv_hander7;

extern u8 tim3cnt;
extern u8 min_over;

extern u8 An_f;




#endif
