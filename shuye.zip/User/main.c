#include "global.h"

#include "mb_blood.h"
#include "mb_uart1.h"
#include "mb_down.h"
#include "mb_led.h"
#include "mb_pump.h"


#include "ESP8266.h"
#include "oled.h"
#include "hw.h"







int main(void)
{
	u8 i,keynu=0;
	delay_init();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
                                                                                  
	OLED_Init();
	hw_init();
	key_init();
	pump_Init();

	UART1_init();
	blood_init();
	display3();//������Һϵͳ
	blood_clibration(0x80,0x4a,0x4b); //У��
	printf("start------------------------\r\n");
	
	while(1)
	{

		if(An_f & 0x80)
		{
			An_f &= 0x7f;
			keynu=1;
		}
		if(An_f & 0x40)
		{
			An_f &=0xBf;
			keynu=2;

		}
		if(An_f & 0x20)
		{
			An_f &=0xDf;
			keynu=3;
			i++;
			if(i>=10)
			{
			i=0;
			}
		}		
		
		if(keynu==1)
		{
			clean();
			display2(); //Ѫѹֵ
			rcv_hander1=0;				
		}
		if(keynu==2)
		{
			clean();
			display();	//�������
		}
		if(keynu==3)
		{
			if(i%2!=0)
			{
				pump_open(1000);	
				}else
				{
				PUMP_SET=0;
			}		
		}		
		

	
		
		
		
//			display();
//			delay_ms(1500);
//			clean();
//			display1();
//			delay_ms(1500);
//			clean();
//			display2();
//			delay_ms(1500);
//			clean();
		blood_ReadDate();
//		blood_ReadECC();

		
//		if(rcv_hander3==2)//�������
//		{
//		OLED_ShowString(5,4,"ECG:",16);	
//		OLED_ShowNum(60,4,((u16)blood_data[5]<<8)+((u16)blood_data[6]&0xff00),3,16);							
//		printf("ECG�ĵ��ź�:%d\r\n",((u16)blood_data[5]<<8)+((u16)blood_data[6]&0xff00));//5-6�ĵ�
//		rcv_hander3=0;
//		}				
//		
//		delay_ms(1500);
		
		


	}
}

//		printf("%d,%d,%d\r\n",blood_data[0],blood_data[1],blood_data[2]); //0-2���������ţ�����
