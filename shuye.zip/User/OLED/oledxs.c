#include "oled.h"
#include "hw.h"
#include "global.h"

extern u8 blood_data[BLOOD_LEN];
void  display(void)//��Һ�ٶ���ʾ
{
	  OLED_ShowCHinese(20,2,8);//��
		OLED_ShowCHinese(36,2,9);//Һ
		OLED_ShowCHinese(52,2,10);//��
	  OLED_ShowCHinese(68,2,11);//��
		OLED_ShowCHinese(84,2,12);//Ϊ
	  OLED_ShowCHinese(100,2,13);//��
		OLED_ShowNum(18,5,cnt,3,16);
//	  OLED_shuzi(16,4,cnt/100*2);
//	  OLED_shuzi(32,4,cnt%100/10*2);
//	  OLED_shuzi(48,4,cnt%10*2);
//	  OLED_shuzi(16,4,cnt/100);
//	  OLED_shuzi(32,4,cnt%100/10);
//	  OLED_shuzi(48,4,cnt%100%10);	
	  OLED_shuzi(64,4,24);//��
	  OLED_shuzi(80,4,20);//��ʾ/
	  OLED_shuzi(96,4,26);//�� 
}
void  display1(void)//������ʾ
{
	  OLED_ShowCHinese(20,2,14);//��
	  OLED_ShowCHinese(36,2,15);//ǰ
	  OLED_ShowCHinese(52,2,16);//��
		OLED_ShowCHinese(68,2,17);//��
	  OLED_ShowCHinese(84,2,18);//Ϊ
	  OLED_ShowCHinese(100,2,19);//��
    OLED_shuzi(24,4,14);//
	  OLED_shuzi(40,4,12);//
	  OLED_shuzi(56,4,28);//��
	  OLED_shuzi(72,4,20);//��ʾ��/��
	  OLED_shuzi(88,4,26);//�� 
	}
void  display2(void)
{
    OLED_ShowCHinese(20,2,20);//��
	  OLED_ShowCHinese(36,2,21);//ǰ
	  OLED_ShowCHinese(52,2,22);//Ѫ
		OLED_ShowCHinese(68,2,23);//ѹ
	  OLED_ShowCHinese(84,2,24);//Ϊ
	  OLED_ShowCHinese(100,2,25);//��
	OLED_ShowNum(18,5,blood_data[0],3,16);
//    OLED_shuzi(20,4,blood_data[0]/100);
//	
//	  OLED_shuzi(40,4,blood_data[0]%100/10);
//		OLED_shuzi(40,4,blood_data[0]%10);
	  OLED_shuzi(58,4,20);//��ʾ��/��
	OLED_ShowNum(73,5,blood_data[1],3,16);
//	  OLED_shuzi(80,4,blood_data[1]/10);
//	  OLED_shuzi(100,4,blood_data[1]%10);
}

void display3(void )//������Һϵͳ
{
    OLED_ShowCHinese(0,0,0);//��
		OLED_ShowCHinese(16,0,1);//��
		OLED_ShowCHinese(32,0,2);//��
		OLED_ShowCHinese(48,0,3);//Һ
		OLED_ShowCHinese(64,0,4);//��
		OLED_ShowCHinese(80,0,5);//��
	  OLED_ShowCHinese(96,0,6);//ϵ
		OLED_ShowCHinese(112,0,7);//ͳ

}
