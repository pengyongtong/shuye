/**************************************************************************
�汾����˵��:
/////////////////////////////////////////////////////
2016.12.31
����
void str_midn(u8 *ucDes,u8 *ucSrc,u8 ucStart,u8 ucLen)
ԭbug��ucStartȡ��λ����1
ԭ��ucSrc=ucSrc+ucStart
�֣�if(ucStart!=0)
		ucSrc=ucSrc+ucStart-1;

2017.1.3
2�����mycommon�ļ��ֳ���myfilter��mycheck��
/////////////////////////////////////////////////////
**************************************************************************/
#ifndef __MYSTRING_H
#define __MYSTRING_H
#include "mytype.h"

void str_set0(u8 *ucMemAddr,u32 ucLen);
void str_set(u8 *ucMemAddr,u8 ucValue,u32 ucLen);
void str_cpy(u8 *ucDes,u8 *ucSrc);
void str_cpyn(u8 *ucDes,u8 *ucSrc,u32 ucLen);
void str_cat(u8 *ucDes,u8 *ucSrc);
void str_catn(u8 *ucDes,u8 *ucSrc,u32 ucLen);
void str_catn_ex(u8 *ucDes,u8 *ucSrc1,u32 ucLen1,u8 *ucSrc2,u32 ucLen2);
u16 str_len(u8 *ucStr);
u8 str_lenw(u8 *ucStr);
u8 str_lennum(u16 uiNum);
BOOLEAN str_cmp(u8 *ucDes,u8 *ucSrc);
BOOLEAN str_cmpn(u8 *ucDes,u8 *ucSrc,u32 ucLen);
BOOLEAN str_str(u8 *ucStr,u8 *ucSub);
BOOLEAN str_strn(u8 *ucSrc,u8 *ucSub,u32 uiLenSrc);
u8 str_subpos(u8 *ucStr,u8 *ucSub);
BOOLEAN str_subn(u8 *ucDes,u8 *ucStr,u8 *ucSub,u8 ucStart,u8 ucLen);
void str_left(u8 *ucDes,u8 *ucSrc1,u8 *ucSrc2);
void str_rightn(u8 *ucDes,u8 *ucSrc,u8 ucStart);

BOOLEAN str_mid(u8 *ucDes,u8 *ucSrc1,u8 *ucSrc2,u8 *ucSrc3);
void str_midn(u8 *ucDes,u8 *ucSrc,u8 ucStart,u8 ucLen);
void str_midse(u8 *ucDes,u8 *ucSrc,u8 ucStart,u8 ucEnd);

u8 str_add0d0a(u8 *ucDes,u8 *ucSrc);


#endif
