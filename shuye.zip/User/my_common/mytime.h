#ifndef __MYTIME_H_
#define __MYTIME_H_
#include "mytype.h"
BOOLEAN mtime_isleapyear(u8 ucYear);
BOOLEAN mtime_calcmp(CALENDAR *stCal1,CALENDAR *stCal2);
u32 mtime_getbaseday(CALENDAR *stCal);
u32 mtime_getbaseminute(CALENDAR *stCal);
s32 mtime_subminute(CALENDAR *stCal1,CALENDAR *stCal2);
void mtime_caltodate(MYDATE *stDate,CALENDAR *stCal);
u8 mtime_datetoweek(MYDATE *stDate);
BOOLEAN mtime_chkcal(CALENDAR *stCal);
BOOLEAN mtime_chkyear(u8 ucYear);
BOOLEAN mtime_chkmonth(u8 ucMonth);
BOOLEAN mtime_chkday(u8 ucDay);
BOOLEAN mtime_chkhour(u8 ucHour);
BOOLEAN mtime_chkminute(u8 ucMinute);
BOOLEAN mtime_chkseconde(u8 ucSeond);
void mtime_tocp56time2a(CP56TIME2A *stTime,CALENDAR *stCal);
void mtime_frmcp56time2a(CALENDAR *stCal,CP56TIME2A *stTime);
#endif
