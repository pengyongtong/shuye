#ifndef __MYCONVERT_H
#define __MYCONVERT_H
#include "mytype.h"
#define CON_SPUSART_MAXNUM	12
#define CON_SPCAN_MAXNUM		10
/************************************************************/
//����֮���໥ת��
u8 con_bcdtodec2(u8 ucBcd);
u8 con_dectobcd2(u8 ucDec);
u16 con_dectobcd4(u16 uiDec);
void con_dectobcdn(u8 *ucBcd,u8 *ucDec,u8 ucLen);
u8 con_str2bcdtouc(u8 *ucBcd);
u16 con_uctostr2bcd(u8 ucNum);
u32 con_str8bcdtoul(u8 *ucBcd);
void con_ultostr8bcd(u8 *ucBcd,u32 ulNum);
/************************************************************/
//���ֺ��ַ��ַ����໥ת��
u8 con_tolower(u8 ucChra);
u8 con_toupper(u8 ucChrA);
u8 con_dectoasc(u8 ucDec);
u8 con_dectochar(u8 ucDec);
u8 con_hextoascA(u8 ucHex);
u8 con_hextocharA(u8 ucHex);
u8 con_hextoasca(u8 ucHex);
u8 con_hextochara(u8 ucHex);
BOOLEAN con_dectoascn(u8 *ucDsc,u8 *ucSrc,u8 ucLen);
BOOLEAN con_asctodecn(u8 *ucDec,u8 *ucSrc,u8 ucLen);
BOOLEAN con_dectostr2(u8 *ucStr,u8 ucDec);
void con_uctostr(u8 *ucDec,u8 ucNum);
u8 con_strtodec2(u8 *ucDec);
u16 con_strtohex4(u8 *ucStr);
/************************************************************/
//���ֺ��ַ�������ת������Ƹ���8��32λ������С�˴洢
u16 con_endian_chg16(u16 uiSrc);
void con_ultobyte_be(u8 *ucDes,u32 ulSave);
void con_ultobyte_le(u8 *ucDes,u32 ulSave);
void con_uitobyte_be(u8 *ucDes,u16 uiSave);
void con_uitobyte_le(u8 *ucDes,u16 uiSave);
void con_ul24btobyte_be(u8 *ucDes,u32 ulSave);
void con_ul24btobyte_le(u8 *ucDes,u32 ulSave);
u32 con_bytetoul_be(u8 *ucSrc);
u32 con_bytetoul_le(u8 *ucSrc);
u16 con_bytetoui_be(u8 *ucSrc);
u16 con_bytetoui_le(u8 *ucSrc);
u32 con_bytetoul24b_be(u8 *ucSrc);
u32 con_bytetoul24b_le(u8 *ucSrc);
u32 con_strtodec(u8 *ucStr);
u32 con_strntodec(u8 *ucStr,u8 ucLen);
u32 con_strasctodec(u8 *ucStr);
u16 con_uiswHL(u16 uiData);//16λ�������ߵ�8λ
void con_uiswHLStrn(u8 *ucSrc,u8 ucLen);
u32 con_ulswHL(u32 ulSrc);
u32 con_tousartsp(u8 ucNum);
u8 con_usartsp_tonum(u32 ulSp);
u16 con_tocansp(u8 ucNum);
u8 con_cansp_tonum(u16 uiSp);
void con_xchgbyte(u8 *ucT1,u8 *ucT2);
#endif
