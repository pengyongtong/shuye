#ifndef __MYCHECK_H
#define __MYCHECK_H
#include "mytype.h"
u8 chk_getsum(u8 *ucChk,u32 ucLen);//�õ�У���
BOOLEAN chk_chksum(u8 *ucChk,u32 ucLen,u8 ucSum);
u16 chk_getsum_ex(u8 *ucChk,u8 ucLen);//�õ�У���;
BOOLEAN chk_chkclenum(u8 *ucCelNum);
BOOLEAN chk_hour24(u8 ucHour);
BOOLEAN chk_miniute(u8 ucMinute);
BOOLEAN chk_second(u8 ucSecond);
BOOLEAN chk_calendar(CALENDAR *stCal);
u8 chk_getxor(u8 *ucChk,u8 ucLen);//�õ����
#endif
