#include "global.h"



extern BLOOD_ORDER blood_rev_order;


extern u8 uart3Rxbuf[U3RXLEN];
extern u8 u3cnt;



extern u8 tim3cnt;

extern u8 blood_cycle;

extern u8 cnt;//��¼Һ��������
extern u8 An_f;












