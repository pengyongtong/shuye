satartup._stm32f10x_cl.s:互联产品，stm32f105/107系列
_hd.s:高密度产品，flash大于128
_hd_vl.s---vl:超值型产品：stm32f100系列
_ld.s----ld:低密度产品，flash小于64k
ld_vl.s
md.s---md 中等密度产品，flash64 or 128
md.vl.s
xl.s---xl ：超高密度（容量）产品，stm32f101/103系列