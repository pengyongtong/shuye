#ifndef   _anjian_h
#define   _anjian_h
#include "sys.h"

extern  u8  bj;

void anjian_init(void);
void anjian_check(void);
#endif

