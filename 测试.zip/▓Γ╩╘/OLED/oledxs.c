#include "oled.h"
#include "delay.h"
#include "anjian.h"
#include "hw.h"
void  display(void)
{
	 xs1(0,0x01,1,128);
	 xs(128,0xff,1);
	 xs1(7,0x80,0,127);
	 xs(2,0xff,0);
	OLED_ShowCHinese(24,1,0);
	OLED_ShowCHinese(40,1,1);
	OLED_ShowCHinese(56,1,2);
	OLED_ShowCHinese(72,1,3);
	OLED_ShowCHinese(88,1,4);//��ʾϵͳ������

	 OLED_ShowCHinese(32,3,5);
   delay_ms(60000);
	 OLED_ShowCHinese(50,3,5);
   delay_ms(60000);
	 OLED_ShowCHinese(68,3,5);
   delay_ms(60000);
	 OLED_ShowCHinese(84,3,5);
   delay_ms(60000);           
		
}
void  display1(void)//������ʾ
{
	     xs2(2,0x01,1,32);
	     xs3(0,0xff,2,3);
	     xs2(3,0x80,1,32);
	     xs3(1,0xff,2,3);
	     xs2(2,0x01,80,129);
	     xs3(0,0xff,128,129);
       xs2(3,0x80,80,129);
	     xs3(1,0xff,128,129);
	
	    xs3(2,0xff,128,129);
	    xs3(3,0xff,128,129);
	    xs3(4,0xff,128,129);
	    xs3(5,0xff,128,129);
	    xs3(6,0xff,128,129);
	    xs3(7,0xff,128,129);
	
	    xs3(2,0xff,1,3);
	    xs3(3,0xff,1,3);
	    xs3(4,0xff,1,3);
	    xs3(5,0xff,1,3);
	    xs3(6,0xff,1,3);
	    xs3(7,0xff,1,3);
			
			xs3(4,0xff,51,52);
			xs3(5,0xff,51,52);
			
			xs3(6,0xff,51,52);
			xs3(7,0xff,51,52);
			
			xs3(4,0xff,76,77);
			xs3(5,0xff,76,77);
			
			xs3(6,0xff,76,77);
			xs3(7,0xff,76,77);
	    
	    xs2(6,0x01,52,56);
	    xs2(7,0x80,52,56);
			
			xs2(6,0x01,72,76);
	    xs2(7,0x80,72,76);
			
			xs2(7,0x80,77,128);
			
	    OLED_ShowCHinese1(3,0,0);
	    OLED_ShowCHinese1(17,0,1);
			OLED_ShowCHinese1(33,0,2);
	    OLED_ShowCHinese1(49,0,3);
			OLED_ShowCHinese1(65,0,4);
	    OLED_ShowCHinese1(81,0,5);
			OLED_ShowCHinese1(97,0,6);
	    OLED_ShowCHinese1(112,0,7);//��ʾ������Һ����ϵͳ
			
			OLED_ShowCHinese1(32,2,8);
	    OLED_ShowCHinese1(48,2,9);
			OLED_ShowCHinese1(64,2,10);
	    OLED_ShowCHinese1(80,2,11);//�ڶ�����ʾ����ν��桰
			
			OLED_ShowCHinese1(3,4,12);
	    OLED_ShowCHinese1(19,4,13);
	    OLED_ShowCHinese1(35,4,16);//��������ʾ�ٶ�
			
	    OLED_ShowCHinese1(3,6,14);
	    OLED_ShowCHinese1(19,6,15);
	    OLED_ShowCHinese1(35,6,16);//��������ʾ״̬
			
			OLED_shuzi(52,4,0);
			OLED_shuzi(60,4,0);
			OLED_shuzi(68,4,0);//�ٶ�Ĭ��Ϊ0
			
			OLED_ShowCHinese1(56,6,18);//״̬����ʾ��
	}
void display11(u8 aa,u16 ds)
{
		
		
		while(aa)
		{
			OLED_ShowCHinese1(56,6,17);//״̬����ʾ��
		  OLED_shuzi(52,4,ds/100);
			OLED_shuzi(60,4,ds%100/10);
			OLED_shuzi(68,4,ds%10);
			OLED_ShowCHinese(93,5,6);//��ʾ���
		  delay_ms(60000);
		  OLED_shuzi(52,4,ds/100);
			OLED_shuzi(60,4,ds%100/10);
			OLED_shuzi(68,4,ds%10);
		  OLED_clean_dy(95,5,0x00);
		  delay_ms(60000);
		} 
	}
void  display2(void)
{
		 xs2(2,0x01,1,32);
		 xs3(0,0xff,2,3);
		 xs2(3,0x80,1,32);
		 xs3(1,0xff,2,3);
		 xs2(2,0x01,80,129);
		 xs3(0,0xff,128,129);
		 xs2(3,0x80,80,129);
		 xs3(1,0xff,128,129);
	
	    xs3(2,0xff,128,129);
	    xs3(3,0xff,128,129);
	    xs3(4,0xff,128,129);
	    xs3(5,0xff,128,129);
	    xs3(6,0xff,128,129);
	    xs3(7,0xff,128,129);
	
	    xs3(2,0xff,1,3);
	    xs3(3,0xff,1,3);
	    xs3(4,0xff,1,3);
	    xs3(5,0xff,1,3);
	    xs3(6,0xff,1,3);
	    xs3(7,0xff,1,3);
			
			xs3(4,0xff,51,52);
			xs3(5,0xff,51,52);
			
			xs3(6,0xff,51,52);
			xs3(7,0xff,51,52);
			
			xs3(4,0xff,76,77);
			xs3(5,0xff,76,77);
			
			xs3(6,0xff,76,77);
			xs3(7,0xff,76,77);
	    
	    xs2(6,0x01,52,56);
	    xs2(7,0x80,52,56);
			
			xs2(6,0x01,72,76);
	    xs2(7,0x80,72,76);
			
			xs2(7,0x80,77,128);
			
	    OLED_ShowCHinese1(3,0,0);
	    OLED_ShowCHinese1(17,0,1);
			OLED_ShowCHinese1(33,0,2);
	    OLED_ShowCHinese1(49,0,3);
			OLED_ShowCHinese1(65,0,4);
	    OLED_ShowCHinese1(81,0,5);
			OLED_ShowCHinese1(97,0,6);
	    OLED_ShowCHinese1(112,0,7);//��ʾ������Һ����ϵͳ
			
			OLED_ShowCHinese1(32,2,23);
	    OLED_ShowCHinese1(48,2,20);
			OLED_ShowCHinese1(64,2,10);
	    OLED_ShowCHinese1(80,2,11);//�ڶ�����ʾ��Ѫѹ���桰
			
			OLED_ShowCHinese1(3,4,19);
	    OLED_ShowCHinese1(19,4,20);
	    OLED_ShowCHinese1(35,4,16);//��������ʾ��ѹ
			
	    OLED_ShowCHinese1(3,6,21);
	    OLED_ShowCHinese1(19,6,22);
	    OLED_ShowCHinese1(35,6,16);//��������ʾ��ѹ
			
			OLED_shuzi(52,4,0);
			OLED_shuzi(60,4,0);
			OLED_shuzi(68,4,0);//��ѹ��Ĭ��Ϊ��
			
			OLED_shuzi(52,6,0);
			OLED_shuzi(60,6,0);
			OLED_shuzi(68,6,0);//��ѹ��Ĭ��Ϊ��
			
				OLED_ShowCHinese(93,5,7);//��ʾ���
}
void  display22(u8 aa,u8  gy,u8 dy)
{
	
	while(aa)
	{
      OLED_shuzi(52,4,gy/100);
			OLED_shuzi(60,4,gy%100/10);
			OLED_shuzi(68,4,gy%10);
		  OLED_shuzi(52,6,dy/100);
			OLED_shuzi(60,6,dy%100/10);
			OLED_shuzi(68,6,dy%10);
		  OLED_ShowCHinese(93,5,7);
		  delay_ms(60000);
		  delay_ms(60000);
		  OLED_shuzi(52,4,gy/100);
			OLED_shuzi(60,4,gy%100/10);
			OLED_shuzi(68,4,gy%10);
	    OLED_shuzi(52,6,dy/100);
			OLED_shuzi(60,6,dy%100/10);
			OLED_shuzi(68,6,dy%10);
		  OLED_clean_dy(93,5,0x00);
		  delay_ms(60000);
		  delay_ms(60000);
}
	}
void  display3(void)
{
   	   xs2(2,0x01,1,32);
	     xs3(0,0xff,2,3);
	     xs2(3,0x80,1,32);
	     xs3(1,0xff,2,3);
	     xs2(2,0x01,80,129);
	     xs3(0,0xff,128,129);
       xs2(3,0x80,80,129);
	     xs3(1,0xff,128,129);
	
	    xs3(2,0xff,128,129);
	    xs3(3,0xff,128,129);
	    xs3(4,0xff,128,129);
	    xs3(5,0xff,128,129);
	    xs3(6,0xff,128,129);
	    xs3(7,0xff,128,129);
	
	    xs3(2,0xff,1,3);
	    xs3(3,0xff,1,3);
	    xs3(4,0xff,1,3);
	    xs3(5,0xff,1,3);
	    xs3(6,0xff,1,3);
	    xs3(7,0xff,1,3);
			
//			xs3(4,0xff,51,52);
//			xs3(5,0xff,51,52);
//			
//			xs3(6,0xff,51,52);
//			xs3(7,0xff,51,52);
//			
			xs3(4,0xff,76,77);
			xs3(5,0xff,76,77);
			
			xs3(6,0xff,76,77);
			xs3(7,0xff,76,77);
			
			xs2(7,0x80,77,128);
			
			xs2(5,0x80,3,7);
			xs2(5,0x80,54,76);
			xs2(7,0x80,49,76);
			xs2(7,0x80,3,18);
			
	    OLED_ShowCHinese1(3,0,0);
	    OLED_ShowCHinese1(17,0,1);
			OLED_ShowCHinese1(33,0,2);
	    OLED_ShowCHinese1(49,0,3);
			OLED_ShowCHinese1(65,0,4);
	    OLED_ShowCHinese1(81,0,5);
			OLED_ShowCHinese1(97,0,6);
	    OLED_ShowCHinese1(112,0,7);//��ʾ������Һ����ϵͳ
			
			OLED_ShowCHinese1(32,2,24);
	    OLED_ShowCHinese1(48,2,25);
			OLED_ShowCHinese1(64,2,10);
	    OLED_ShowCHinese1(80,2,11);//�ڶ�����ʾ��������桰
			
		   OLED_ShowCHinese1(7,4,26);
	     OLED_ShowCHinese1(23,4,27);
			 OLED_ShowCHinese1(39,4,14);
	     OLED_ShowCHinese1(53,4,15);
			 
			 OLED_ShowCHinese1(18,6,28);
			 OLED_ShowCHinese1(31,6,26);
	     OLED_ShowCHinese1(48,6,27);//��ʾ������
			 
			 OLED_ShowCHinese(93,5,10);//��ʾwifiͼ��		 
}

void  menu(u8  hh)
{
  switch(hh)
	{
		case 0:display();anjian_check();break;
		case 1:OLED_Clear();bj++;break;
		case 2:display2();bj++;break;
		case 3:display22(1,0,0);break;
		default:break;
	}
}
	
