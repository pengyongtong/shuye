#include "stm32f10x.h"
#include "hw.h"
#include "sys.h"
#include "delay.h"
#include "oled.h"
#include "bmp.h"
#include "anjian.h"
#include "stm32f10x_exti.h"
int main(void)
{	
	  delay_init();	 
		OLED_Init();
	  anjian_init();
    OLED_Clear();
//	display3();
  while(1)
	{
		menu(bj);
	}
 }
